
#include "matrixfunc.h"
 int row1,column1,row2,column2,row3,column3 , i , j;
void addition(int m[][50],int n[][50]){
   int i,j ;

  int c[row1][column1];
 printf("the sum of the two matrix is:\n");
    for (i=0;i<row1;i++){
        for(j=0;j<column1;j++){
         c[i][j]=m[i][j]+n[i][j];
        printf("%-06d\t",c[i][j]);
         }
         printf("\n");
         }
         }

    void subtractin(int m[][50],int n[][50]){
     int i , j ;

    int c[row1][column1]  ;
    printf("the subtraction of the two matrix is:\n");
    for (i=0;i<row1;i++){
        for(j=0;j<column1;j++){
         c[i][j]=m[i][j]-n[i][j];
         printf("%-06d\t",c[i][j]);
         }
         printf("\n");
         }
         }
         void transpose1(int m[][50]){
          int c[column1][row1];
          printf("the transpose of first matix2 is \n");
          for(i=0 ;i<column1;i++){
            for(j=0;j<row1;j++){
              c[i][j]=m[j][i];
              printf("%-06d\t",c[i][j]);
            }
            printf("\n");
          }
         }
         void transpose2(int m[][50]){
          int c[column2][row2];
          printf("the transpose of first matix2 is \n");
          for(i=0 ;i<column2;i++){
            for(j=0;j<row2;j++){
              c[i][j]=m[j][i];
              printf("%-06d\t",c[i][j]);
            }
            printf("\n");
          }
         }
         void multipication(int m[][50],int n[][50]){
           int i , j ,k ;
           int c[row1][column2];
           printf("the multipication of two matrix is :\n");
              for (int i = 0; i < row1; i++)
               {
                 for (int j = 0; j < column2; j++)
                 {
                 int sum = 0;
                 for (int k = 0; k < row2; k++)
                   sum += m[i][k] * n[k][j];
                  c[i][j] = sum;
                 }
                }
                for(i=0; i<row1;i++){
                  for(j=0;j<column2;j++){
                    printf("%-06d\t",c[i][j]);
                  }
                  printf("\n");
                }
         }
