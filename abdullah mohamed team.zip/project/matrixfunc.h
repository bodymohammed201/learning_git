#ifndef MATRIXFUNC_H_INCLUDED
#define MATRIXFUNC_H_INCLUDED

#include <stdio.h>
#include <math.h>
void addition(int  m[][50],int n[][50]);
 void subtractin(int m[][50],int n[][50]);
 void transpose1(int m[][50]);
 void transpose2(int m[][50]);
  void multipication(int m[][50],int n[][50]);
  extern int row1,column1,row2,column2,row3,column3 , i , j;

#endif // MATRIXFUNC_H_INCLUDED
