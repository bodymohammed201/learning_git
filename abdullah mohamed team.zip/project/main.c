
#include "matrixfunc.h"
int main(void){

  char sign;
  int matrix1[50][50] , matrix2[50][50], matrix_result[50][50];
  printf("\n******* Matrix1 *******\n\n\n");
  printf("Enter the number of rows  of the  matrix1 maximum 50 :\n\n");
  scanf("%d",&row1);
  printf("Enter the number of columns of the matrix1 maximum 50 :\n\n");
  scanf("%d",&column1);
  printf("Enter the element of matrix1 \n ");
  for (i=0;i<row1;i++){

       for(j=0;j<column1;j++){
             printf(" enter element[%d][%d]:",i+1 , j+1 );

             scanf("%d",&matrix1[i][j]);
      }

  }
  printf("\n\n******* Matrix2 *******\n\n\n");
  printf("Enter the number of rows  of the  matrix2 maximum 50 :\n\n");
  scanf("%d",&row2);
  printf("Enter the number of columns of the matrix2 maximum 50 :\n\n");
  scanf("%d",&column2);
  printf("Enter the elements of matrix2 \n");
  for (i=0;i<row2;i++){

       for(j=0;j<column2;j++){
             printf(" enter element[%d][%d]:",i+1 , j+1 );

             scanf("%d",&matrix2[i][j]);
      }

  }
  printf("\nthe first matrix that you enter with system %d x %d  is:\a\n" ,row1,column1);
  for (i=0;i<row1;i++){
       for(j=0;j<column1;j++){
            printf("%-06d\t",matrix1[i][j]) ;
       }
         printf("\n");
       }
       printf("\n----------------------------------------\n");
        printf("\nthe second matrix that you enter with system %d x %d   is:\a\n", row2,column2);
  for (i=0;i<row2;i++){
       for(j=0;j<column2;j++){
            printf("%-06d\t",matrix2[i][j]) ;
       }
         printf("\n");
       }

     if(row1==row2 && column1==column2){

      for(i=0;i<5;i++){

    printf("\n***Enter the calculation that you need + for add or - suptraction or *for multipication or / or t for transpose or b to break :****\n");// '+'or '-'
    fflush(stdin);
    scanf("%s",&sign);
    if(sign == '*' && column1==row2){
      multipication(matrix1,matrix2);
    }
    if(sign == '*' && column1!=row2){
      printf("****you cannot make multibication as row2 not equal column1***** \n");
    }

    if(sign =='+'){
      addition(matrix1,matrix2);
    }

    if(sign=='-'){
    subtractin(matrix1,matrix2);

   }
   if(sign=='t'){
    transpose1(matrix1);
    transpose2(matrix2);
   }
   if(sign=='b'){
    printf("programme ended\n");
    break;
   }

   else{
    //do nothing
   }


   }

}
     else if((column1 == row2 && row1 != column2) ||(column1 == row2 && row1 == column2) ){
      printf("\nthe additional and subtraction are not br able to calculate\n");
      for(i=0;i<3;i++){
        printf("\nenter the calculatin that you need * for multipication or t for transbort or b to break\n");
        fflush(stdin);
         scanf("%s",&sign);
         if(sign=='t'){
    transpose1(matrix1);
    transpose2(matrix2);
   }
   if(sign == '*' ){
      multipication(matrix1,matrix2);
    }
    if(sign=='b'){
    break;
    }
      }

     }

     else{
      printf("\nyou can make transpose only if you want enter t\n ");
      fflush(stdin);
         scanf("%s",&sign);
      if(sign=='t'){
    transpose1(matrix1);
    transpose2(matrix2);
   }
   else{

   }
     }
}
